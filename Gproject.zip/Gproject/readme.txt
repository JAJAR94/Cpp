change directory path in globals.cpp If you don't use cmake
directorypath_s = "students/"
directorypath_t = "teachers/"