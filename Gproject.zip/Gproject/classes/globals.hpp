#ifndef GLOBALS_H
#define GLOBALS_H
#include <string>
extern std::string directorypath_s;
extern std::string directorypath_t;


#endif