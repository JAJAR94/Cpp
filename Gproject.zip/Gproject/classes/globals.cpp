#include "globals.hpp"
std::string directorypath_s = "../students/";
std::string directorypath_t = "../teachers/";